create procedure p_staff(
    sid in varchar2,
    cur_out out sys_refcursor,
    o_result out integer)
is
begin
  open cur_out for
    select id,sname,email,phone
    from staff
    where staff.sid = sid;
  o_result := 1;
exception
  when others then
    o_result := -163;
end p_staff;
/

