create view V_ANIMAL as
select animal.id,ano,aname,type,sex,age,shelter.name
from animal,shelter
where animal.sid = shelter.id
/

