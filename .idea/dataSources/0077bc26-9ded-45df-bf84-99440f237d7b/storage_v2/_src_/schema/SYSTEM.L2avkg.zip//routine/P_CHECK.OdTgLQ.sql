create procedure p_check
(hid varchar2,
 aid varchar2,
 stid varchar2,
 status varchar2,
 checkdate varchar2,
 remark varchar2)
as
begin
    insert into health
    values(hid,aid,stid,status,checkdate,remark);
end p_check;
/

