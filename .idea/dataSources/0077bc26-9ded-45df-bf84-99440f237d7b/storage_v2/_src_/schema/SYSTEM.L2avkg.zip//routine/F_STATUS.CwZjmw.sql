create function f_status(aid in varchar2)
return varchar2
as
  x varchar2(20);
begin
  select status
  into x
  from
    (select * from health
     where health.aid = aid
     order by checkdate)
  where rownum<2;   -- 要加；
  return x;
end f_status;
/

