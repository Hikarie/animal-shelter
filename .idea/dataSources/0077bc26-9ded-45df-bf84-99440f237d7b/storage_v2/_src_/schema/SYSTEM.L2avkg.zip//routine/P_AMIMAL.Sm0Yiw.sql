create procedure p_amimal(
    sid in varchar2,
    cur_out out sys_refcursor,
    o_result out integer)
is
begin
  open cur_out for
    select * 
    from animal
    where staff.sid = sid;
  o_result := 1;
exception
  when others then
    o_result := -163;
end p_animal;
/

