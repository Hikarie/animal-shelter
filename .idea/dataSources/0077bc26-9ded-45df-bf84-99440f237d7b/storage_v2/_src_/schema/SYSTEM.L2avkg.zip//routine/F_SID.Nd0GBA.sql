create function f_sid(stid in varchar2)
    return varchar2
as
    x varchar2(20);
begin
    select SID
    into x
    from
        (select * from staff
         where staff.ID = stid
        )
    where rownum<2;   -- 要加；
    return x;
end f_sid;
/

