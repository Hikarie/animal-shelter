create trigger SHELTER_STAFF
    after insert or delete
    on SHELTER
    for each row
declare
shid varchar2(20);
infor varchar2(50);
begin
  if inserting then
    shid := :new.id;
    infor := 'create a shelter named '+shid;
    execute immediate 'create or raplace view V_'||shid||'_staff(id,sname,email,phone)
                        as select id,name,emial,phone from staff where sid=:20'
    using shid;
  else
    shid := :old.id;
    infor := 'delete a shelter named '+shid;
    execute immediate 'drop view V_'||shid||'_staff';
  end if;
end shelter_staff;
/

